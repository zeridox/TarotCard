var scripty = document.createElement('script');
document.body.appendChild(scripty);

for(var i=1; i<=3; i++){
    
    let output2 = "var value"+i+"= Math.floor(Math.random()*4)+1;"
    scripty.append(output2);  
    let output3 = "var card"+i+" = document.getElementById('card"+i+"');";
    scripty.append(output3);
    // let output = "var suit"+i+"= Math.floor(Math.random()*4)+1;"
    // scripty.append(output);
    // scripty.append("card"+i+".innerText = suit"+i+";");
};
var clicke = 0;
function drawCard(){
    ts = document.getElementById('tense');
    hs = document.getElementById('headin');
    ds = document.getElementById('description');
    suit = Math.floor(Math.random()*4)+1;
    value = Math.floor(Math.random()*14)+1;
    console.log(suit);
    clicke++;
    if(suit == 1){
        suit1="Swords";
        classy="red";
        
    }
    if(suit == 2){
        suit1="Cups";
        classy="blue";
    }
    if(suit == 3){
        suit1="Pentacles";
        classy="yellow";
        
    }
    if(suit == 4){
        suit1="Wands";
        classy="green";
    }
    if(value==1){
        value="Ace"
    }
    if(value==11){
        value="Page"
    }
    if(value==12){
        value="Knight"
    }
    if(value==13){
        value="Queen"
    }
    if(value==14){
        value="King"
    }

    if(clicke == 1){
        ts.innerText = "Past";
        ts.style.color=classy;
        card1.innerText = value+" of "+suit1;
        card1.style.backgroundColor = classy;

    };
    if(clicke == 2){
        ts.innerText = "Present";
        ts.style.color=classy;
        card2.innerText = value+" of "+suit1;
        card2.style.backgroundColor = classy;
    };
    if(clicke == 3){
        ts.innerText = "Future";
        ts.style.color=classy;
        card3.innerText = value+" of "+suit1;
        card3.style.backgroundColor = classy;
    };
   
//Wands
    if(suit==4 && value=="Ace"){
        hs.innerText = "Ace of Wands";
        ds.innerText = acewands;
    }
    if(suit==4 && value==2){
        hs.innerText = "Two of Wands";
        ds.innerText = twowands;
    }
    if(suit==4 && value==3){
        hs.innerText = "Three of Wands";
        ds.innerText = threewands;
    }
    if(suit==4 && value==4){
        hs.innerText = "Four of Wands";
        ds.innerText = fourwands;
    }
    if(suit==4 && value==5){
        hs.innerText = "Five of Wands";
        ds.innerText = fivewands;
    }
    if(suit==4 && value==6){
        hs.innerText = "Six of Wands";
        ds.innerText = sixwands;
    }
    if(suit==4 && value==7){
        hs.innerText = "Seven of Wands";
        ds.innerText = sevenwands;
    }
    if(suit==4 && value==8){
        hs.innerText = "Eight of Wands";
        ds.innerText = eightwands;
    }
    if(suit==4 && value==9){
        hs.innerText = "Nine of Wands";
        ds.innerText = ninewands;
    }
    if(suit==4 && value==10){
        hs.innerText = "Ten of Wands";
        ds.innerText = tenwands;
    }
    if(suit==4 && value=="Page"){
        hs.innerText = "Page of Wands";
        ds.innerText = pagewands;
    }
    if(suit==4 && value=="Knight"){
        hs.innerText = "Knight of Wands";
        ds.innerText = knightwands;
    }
    if(suit==4 && value=="Queen"){
        hs.innerText = "Queen of Wands";
        ds.innerText = queenwands;
    }
    if(suit==4 && value=="King"){
        hs.innerText = "King of Wands";
        ds.innerText = kingwands;
    }
//pentacles
    if(suit==3 && value=="Ace"){
        hs.innerText = "Ace of Pentacles";
        ds.innerText = acepents;
    }
    if(suit==3 && value==2){
        hs.innerText = "Two of Pentacles";
        ds.innerText = twopents;
    }
    if(suit==3 && value==3){
        hs.innerText = "Three of Pentacles";
        ds.innerText = threepents;
    }
    if(suit==3 && value==4){
        hs.innerText = "Four of Pentacles";
        ds.innerText = fourpents;
    }
    if(suit==3 && value==5){
        hs.innerText = "Five of Pentacles";
        ds.innerText = fivepents;
    }
    if(suit==3 && value==6){
        hs.innerText = "Six of Pentacles";
        ds.innerText = sixpents;
    }
    if(suit==3 && value==7){
        hs.innerText = "Seven of Pentacles";
        ds.innerText = sevenpents;
    }
    if(suit==3 && value==8){
        hs.innerText = "Eight of Pentacles";
        ds.innerText = eightpents;
    }
    if(suit==3 && value==9){
        hs.innerText = "Nine of Pentacles";
        ds.innerText = ninepents;
    }
    if(suit==3 && value==10){
        hs.innerText = "Ten of Pentacles";
        ds.innerText = tenpents;
    }
    if(suit==3 && value=="Page"){
        hs.innerText = "Page of Pentacles";
        ds.innerText = pagepents;
    }
    if(suit==3 && value=="Knight"){
        hs.innerText = "Knight of Pentacles";
        ds.innerText = knightpents;
    }
    if(suit==3 && value=="Queen"){
        hs.innerText = "Queen of Pentacles";
        ds.innerText = queenpents;
    }
    if(suit==3 && value=="King"){
        hs.innerText = "King of Pentacles";
        ds.innerText = kingpents;
    }
//Cups
    if(suit==2 && value=="Ace"){
        hs.innerText = "Ace of Cups";
        ds.innerText = acecups;
    }
    if(suit==2 && value==2){
        hs.innerText = "Two of Cups";
        ds.innerText = twocups;
    }
    if(suit==2 && value==3){
        hs.innerText = "Three of Cups";
        ds.innerText = threecups;
    }
    if(suit==2 && value==4){
        hs.innerText = "Four of Cups";
        ds.innerText = fourcups;
    }
    if(suit==2 && value==5){
        hs.innerText = "Five of Cups";
        ds.innerText = fivecups;
    }
    if(suit==2 && value==6){
        hs.innerText = "Six of Cups";
        ds.innerText = sixcups;
    }
    if(suit==2 && value==7){
        hs.innerText = "Seven of Cups";
        ds.innerText = sevencups;
    }
    if(suit==2 && value==8){
        hs.innerText = "Eight of Cups";
        ds.innerText = eightcups;
    }
    if(suit==2 && value==9){
        hs.innerText = "Nine of Cups";
        ds.innerText = ninecups;
    }
    if(suit==2 && value==10){
        hs.innerText = "Ten of Cups";
        ds.innerText = tencups;
    }
    if(suit==2 && value=="Page"){
        hs.innerText = "Page of Cups";
        ds.innerText = pagecups;
    }
    if(suit==2 && value=="Knight"){
        hs.innerText = "Knight of Cups";
        ds.innerText = knightcups;
    }
    if(suit==2 && value=="Queen"){
        hs.innerText = "Queen of Cups";
        ds.innerText = queencups;
    }
    if(suit==2 && value=="King"){
        hs.innerText = "King of Cups";
        ds.innerText = kingcups;
    }
//Swords
    if(suit==1 && value=="Ace"){
        hs.innerText = "Ace of Swords";
        ds.innerText = aceswords;
    }
    if(suit==1 && value==2){
        hs.innerText = "Two of Swords";
        ds.innerText = twoswords;
    }
    if(suit==1 && value==3){
        hs.innerText = "Three of Swords";
        ds.innerText = threeswords;
    }
    if(suit==1 && value==4){
        hs.innerText = "Four of Swords";
        ds.innerText = fourswords;
    }
    if(suit==1 && value==5){
        hs.innerText = "Fivr of Swords";
        ds.innerText = fiveswords;
    }
    if(suit==1 && value==6){
        hs.innerText = "Six of Swords";
        ds.innerText = sixswords;
    }
    if(suit==1 && value==7){
        hs.innerText = "Seven of Swords";
        ds.innerText = sevenswords;
    }
    if(suit==1 && value==8){
        hs.innerText = "Eight of Swords";
        ds.innerText = eightswords;
    }
    if(suit==1 && value==9){
        hs.innerText = "Nine of Swords";
        ds.innerText = nineswords;
    }
    if(suit==1 && value==10){
        hs.innerText = "Ten of Swords";
        ds.innerText = tenswords;
    }
    if(suit==1 && value=="Page"){
        hs.innerText = "Page of Swords";
        ds.innerText = pageswords;
    }
    if(suit==1 && value=="Knight"){
        hs.innerText = "Knight of Swords";
        ds.innerText = knightswords;
    }
    if(suit==1 && value=="Queen"){
        hs.innerText = "Queen of Swords";
        ds.innerText = queenswords;
    }
    if(suit==1 && value=="King"){
        hs.innerText = "King of Swords";
        ds.innerText = kingswords;
    }
    if(clicke >3){
        clicke=0;
        card1.innerText = "Past";
        card2.innerText = "Present";
        card3.innerText = "Future";
        card1.style.backgroundColor = 'white';
        card2.style.backgroundColor = 'white';
        card3.style.backgroundColor = 'white';
        ts.innerText = "";
        ts.style.color='transparent';
        hs.innerText = "Card";
        ds.innerText = "Draw a card to reveal tarot";
    };
};